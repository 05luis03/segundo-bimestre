/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.com.estruturadedados.estruturadedados;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;


/**
 *
 * @author aluno
 */
public class EstruturadeDados {

    public static void main(String[] args) {
       Queue<Integer>fila = new LinkedList<>();
       Scanner scanner = new Scanner(System.in);
       
        System.out.println("Digite os elementos separados por vígula.");
        String input = scanner.nextLine();
        
        
        String[] numeros = input.split(",");
        for (String Numero : numeros){
            fila.offer(Integer.parseInt(Numero.trim()));
        }
        
        System.out.println("Elementos da fila:");
        StringBuilder filaString = new StringBuilder();
        for(Integer numero : fila){
            filaString.append(numero).append(".");
        }
        
        
        //Remover a última virgula se houver elementos na fila
        if (filaString.length()>0){
            filaString.deleteCharAt(filaString.length()-1);
        }
        
        
        System.out.println(filaString.toString());
        scanner.close();
            
        }
}



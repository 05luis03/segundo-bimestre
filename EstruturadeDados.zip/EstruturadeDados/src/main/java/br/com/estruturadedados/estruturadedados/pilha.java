/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.estruturadedados.estruturadedados;
import java.util.Scanner;
import java.util.Stack;
/**
 *
 * @author aluno
 */
public class pilha {
    public static void main(String[] args){
    Stack<Integer> pilha = new Stack<>();
    Scanner scanner = new Scanner(System.in);
    
    System.out.println("Digite os elementos da pilha separados por virgula: ");
    
    //Lê a entrada do usuario com uma lista de texto String input
    String input= scanner.nextLine();
    
    // Digite a entrada em cada elemento separados por virgula
    String[] numeros = input.split(",");
    for(String numero : numeros){
    //converter cada elemento para inteiro e empilha
    pilha.push(Integer.parseInt(numero.trim()));
    }
    
    System.out.println("Elementos da pilha: ");
    
    //Usa StringBuilder para construir a string de saída
    StringBuilder output = new StringBuilder();
    while (!pilha.isEmpty()){
        output.append(pilha.pop()).append(",");
    }
    
    //Remove a ultima vrigula, se houver elementos na pilha
    if (output.length() > 0){
        output.setLength(output.length() -1);
    }
    
    //Imprime aa String resultante
    System.out.println(output.toString().replace(",",",\n"));
    
    scanner.close();
}
}

